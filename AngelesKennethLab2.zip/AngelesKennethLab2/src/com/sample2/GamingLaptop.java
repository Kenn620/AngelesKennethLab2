package com.sample2;

public class GamingLaptop extends Laptop {
	private int SSD;
	
	public GamingLaptop(){
		
	}
	
	public GamingLaptop (String brand, double size, String processor, String gpu, String memory,int SSD) {
		super(brand,size,processor,gpu,memory);
		this.SSD = SSD;
	}
	
	public void setSSD(int SSD) {
		this.SSD = SSD;
	}
	 public int getSSD() {
		 return this.SSD;
	 }
	
	public void bootingUp(String obj) {
		System.out.println("booting up of " + obj + "...");
	}
}