package com.sample2;

public class Test {

	public static void main(String[] args) {
		
		Laptop l1 = new Laptop();
		
		System.out.println("A laptop has been created...");
		l1.setBrand("MSI");
		l1.setGpu("1080ti");
		l1.setMemory("8GB");
		l1.setProcessor("i5 8th Gen");
		l1.setSize(15.6); 
		
	
		System.out.println("Brand: " + l1.getBrand ());
		System.out.println("GPU: " + l1.getGpu());
		System.out.println("Memory: " + l1.getMemory());
		System.out.println("Processor: " + l1.getProcessor());
		System.out.println("Size: " + l1.getSize());
		l1.Browsing("homework");
		
		System.out.println(" ");
		
		GamingLaptop gl1 = new GamingLaptop();
		gl1.setBrand("Acer");
		gl1.setSSD(256);
		gl1.setGpu("GTX 1650");
		gl1.setMemory("64GB");
		gl1.setProcessor("i5 8th Gen");
		gl1.setSize(15.6);
		System.out.println("Brand: " + gl1.getBrand());
		System.out.println("SSD: " + gl1.getSSD());
		System.out.println("GPU: " + gl1.getGpu());
		System.out.println("Processor: " + gl1.getProcessor());
		System.out.println("Size: " + gl1.getSize());
		System.out.println("Memory: " + gl1.getMemory());
		gl1.bootingUp("Windows");
		
		l1 = gl1;
	}
	

}
