package com.sample2;

public class Laptop {
	
	private String brand;
	private double size; 
	private String processor;
	private String gpu;
	private String memory;
	
	public Laptop(){
	}
	
	public Laptop(String brand, double size, String processor, String gpu, String memory ) {
		this.brand = brand;
		this.size = size;
		this.processor = processor;
		this.gpu = gpu;
		this.memory = memory;
	}
	
	public void setBrand(String brand) {
	this.brand = brand;
	
	}
	
	public void setSize(double size) {
		this.size = size;
	}
	public void setProcessor(String processor) {
		this.processor = processor;
	}
	public void setGpu(String gpu) {
		this.gpu = gpu;
	}
	public void setMemory(String memory) {
		this.memory = memory;
	}
	
	public String getBrand() {
		return this.brand;
	}
	public double getSize() {
		return this.size;
	}
	public String getProcessor() {
		return this.processor;
	}
	public String getGpu() {
		return this.gpu;
	}
	public String getMemory() {
		return this.memory;
	}
	
	
	public void Browsing(String subject) {
		System.out.println("Kenn is browsing for his" + subject  + "...");
	}
	
}


